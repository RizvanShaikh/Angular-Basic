import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BehaveServiceService {

  constructor() { }

  private photoUrl = new BehaviorSubject<string>('../../assets/user.png');

  currentPhotoUrl = this.photoUrl.asObservable();

  changeMemberPhoto(photoUrl: string) {
    this.photoUrl.next(photoUrl);
}

// login(model: any) {
//   return this._http.post<AuthUser>(this.baseUrl + 'auth/login', model, { headers: new HttpHeaders()
//       .set('Content-Type', 'application/json') })
//       .map(user => {
//       if (user) {
//           localStorage.setItem('token', user.tokenString);
//           localStorage.setItem('user', JSON.stringify(user.user));
//           this.decodedToken = this._jwtHelperService.decodeToken(user.tokenString);
//           this.currentUser = user.user;
//           this.userToken = user.tokenString;
//           this.changeMemberPhoto(this.currentUser.photoUrl);                          //  <--- Added
//       }
//       });
// }

}
