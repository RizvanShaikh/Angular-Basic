import { TestBed } from '@angular/core/testing';

import { BehaveServiceService } from './behave-service.service';

describe('BehaveServiceService', () => {
  let service: BehaveServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BehaveServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
