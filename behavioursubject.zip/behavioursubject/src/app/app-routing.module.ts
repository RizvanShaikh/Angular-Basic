import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BehaviourComponent } from './behaviour/behaviour.component';


const routes: Routes = [
  {  
    path: 'behaviour',  
    pathMatch: 'full',  
    component: BehaviourComponent  
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
