import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, NgForm } from '@angular/forms';
import { BehaveServiceService } from '../behave-service.service';

@Component({
  selector: 'app-behaviour',
  templateUrl: './behaviour.component.html',
  styleUrls: ['./behaviour.component.css']
})
export class BehaviourComponent implements OnInit {
  title = "behaviour subjct"

  registrationForm: FormGroup;
  isSubmitted: boolean = false;

  
  constructor(
    private formBuilder: FormBuilder,
    private service:BehaveServiceService,
    ) {
    this.registrationForm = this.formBuilder.group({
     
      profilePicUrl: new FormControl('', [
        Validators.required
      ])
      // file: [null, Validators.required]
    });
   }

  ngOnInit( ): void {
  }

  onRegistrationFormSubmit() {
    this.isSubmitted = true;
    if (this.registrationForm.valid) {
   
          this.isSubmitted = true;
          // console.log(this.fileToUpload.type, "<== 52")
          // console.log(this.fileToUpload.size, "file size")
          console.log("User Registration Form Submit", this.registrationForm.value);
    
    }
  }

  fileToUpload: any;
  imageUrl: any;
  handleFileInput(file: FileList) {
    // debugger
    console.log("handelFileInpute 63", file)
    this.fileToUpload = file.item(0);
    
      //  this.onRegistrationFormSubmit()
      //Show image preview
      let reader = new FileReader();
      // console.log("reader 68")
      reader.onload = (event: any) => {
        this.imageUrl = event.target.result;
      }
      reader.readAsDataURL(this.fileToUpload);
  }
  
}
