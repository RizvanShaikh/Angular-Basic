import { Routes, RouterModule } from '@angular/router';
import { CodeemployeeComponent } from './codeemployee.component';

const arr: Routes = [
  { path: '', component: CodeemployeeComponent }
];

export const routingCodeEmpArr = RouterModule.forChild(arr);
