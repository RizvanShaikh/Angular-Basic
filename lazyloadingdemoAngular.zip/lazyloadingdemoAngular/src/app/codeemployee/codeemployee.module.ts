import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CodeemployeeComponent } from './codeemployee.component';
import { routingCodeEmpArr } from './codeemployee.routing';

@NgModule({
  declarations: [
    CodeemployeeComponent,
  ],
  imports: [
    CommonModule,
    routingCodeEmpArr
  ]
})
export class CodeemployeeModule { }
