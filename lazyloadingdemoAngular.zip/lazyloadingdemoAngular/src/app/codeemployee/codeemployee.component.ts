import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-codeemployee',
  templateUrl: './codeemployee.component.html',
  styleUrls: ['./codeemployee.component.css']
})
export class CodeemployeeComponent implements OnInit {

  arr: Array<{ id: number, Name: string, Designation: string}> = [
    { id: 1, Name: 'Deep', Designation: 'CEO'},
    { id: 2, Name: 'Vishal', Designation: 'MEAN Stack Developer'},
    { id: 3, Name: 'Abrar', Designation: 'MEAN Stack Developer'},
    { id: 4, Name: 'Kavya', Designation: 'MEAN Stack Developer'},
    { id: 5, Name: 'Parth', Designation: 'MEAN Stack Developer'},
    { id: 5, Name: 'Krishna', Designation: 'UI/UX Desighner'},
  ];

  constructor() { }

  ngOnInit() {
  }

}
