import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  arr: Array<{ id: number, Name: string, Designation: string}> = [
    { id: 1, Name: 'Nikhil', Designation: 'CEO'},
    { id: 2, Name: 'Baldev', Designation: 'Full Stack Developer'},
    { id: 3, Name: 'Sachin', Designation: 'Full Stack Developer'},
    { id: 4, Name: 'Rizwan', Designation: 'MEAN Stack Developer'},
    { id: 5, Name: 'Pragnesh', Designation: 'MEAN Stack Developer'},
    { id: 5, Name: 'Shreya', Designation: 'MEAN Stack Developer'},
  ];

  constructor() { }

  ngOnInit() {
  }

}
