import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';

const arr: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent},
  { path: 'employee', loadChildren: './employee/employee.module#EmployeeModule'},
  { path: 'codeemployee', loadChildren: './codeemployee/codeemployee.module#CodeemployeeModule'},
  { path: '**', component: HomeComponent }
];
export const routingArr = RouterModule.forRoot(arr);
