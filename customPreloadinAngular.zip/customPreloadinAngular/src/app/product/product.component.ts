import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  arr: Array<{ id: number, phone_Name: string, price: number}> = [
    { id: 1, phone_Name: 'Redmi Note Pro', price: 15999},
    { id: 2, phone_Name: 'Realmi X', price: 14759},
    { id: 3, phone_Name: 'Oppo Reno 2 F', price: 21990},
    { id: 4, phone_Name: 'Vivo Y19', price: 13990},
    { id: 5, phone_Name: 'Samsung Galaxy', price: 8500}
  ];

  constructor() { }

  ngOnInit() {
  }
}
